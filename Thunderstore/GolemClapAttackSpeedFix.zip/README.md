# GolemClapAttackSpeedFix

This fixes the actual attack part of the golem's melee clap attack not scaling with attack speed. Weirdly enough in vanilla the sound still scales with attack speed even though the attack itself doesn't, so it likely wasn't intentional.

## Before

![before](https://github.com/user-attachments/assets/71a3dd6e-3ab5-402d-9e2c-53492cc6b4ea)

## After

![after](https://github.com/user-attachments/assets/00d86ea2-31a8-409f-99ba-d61e50ec973a)
