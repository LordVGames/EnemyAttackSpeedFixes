# GolemClapAttackSpeedFix

This fixes the actual attack part of the golem's melee clap attack not scaling with attack speed. Weirdly enough in vanilla the sound still scales with attack speed even though the attack itself doesn't, so it likely wasn't intentional.

<sub><sup>using videos for the before and after since they're too big as gifs surprisingly</sup></sub>

## Before

https://github.com/user-attachments/assets/12652aa1-313f-403d-ac49-a334d1945ca6

## After

https://github.com/user-attachments/assets/38e187d7-bdc4-491f-86d1-b08887abaae7
