## 1.0.1
- mfw videos don't embed on thunderstore

## 1.0.0

- First release