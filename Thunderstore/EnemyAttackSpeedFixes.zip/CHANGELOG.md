## 1.3.0

- Fixed parent ground slam attack not scaling with attack speed

## 1.2.0

- Fixed stone titan fist attacks not scaling with attack speed
- Fixed stone titan orb thingy's fire rate & rise speed not scaling with attack speed
- - The titan's animation for raising the orb was already scaled, but not the rising speed of the orb itself
- Fixed stone titan laser tick rate not scaling with attack speed
- - Wasn't too sure about this, but void fiend's laser & artificer's flamethrower tick rate scale with attack speed so I think this should as well
- All of the stone titan fixes also apply to Aurelionite

## 1.1.0

- Fixed Mthrix's hammer slam not scaling with attack speed
- Changed mod name to EnemyAttackSpeedFixes

## 1.0.1

- mfw videos don't embed on thunderstore

## 1.0.0

- First release (under the name GolemClapAttackSpeedFix)