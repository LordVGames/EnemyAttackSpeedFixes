## 1.1.0

- Fixed mithrix's hammer slam not scaling with attack speed
- Changed mod name to EnemyAttackSpeedFixes

## 1.0.1

- mfw videos don't embed on thunderstore

## 1.0.0

- First release (under the name GolemClapAttackSpeedFix)